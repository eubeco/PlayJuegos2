package com.example.playjuegos
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.example.playjuegos.R.layout.activity_main as layoutActivity_main


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layoutActivity_main)

        val jugador = findViewById(R.id.Button1) as Button
        jugador.setOnClickListener{ lanzarNewPlayer() }
   }
    fun lanzarNewPlayer(){
        val i = Intent(this, NewPlayer::class.java)
        startActivity(i)
    }

}
